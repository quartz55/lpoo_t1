package maze.Input;

public interface Input {
	String getInput();

	void addInput(String string);
}
